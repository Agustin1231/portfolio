---
name: fichas
description: Reescribe la ficha de un producto de una tienda online usando las dudas reales que mandan los clientes por WhatsApp, agrupadas en patrones. Úsala cuando pida /fichas, mejorar una descripción de producto o una ficha de Shopify.
---

# Fichas de producto que responden antes de que pregunten

Si no te los dio, pide primero:
- El nombre del producto.
- La descripción actual (la de Shopify).
- De 10 a 30 mensajes de clientes sobre ese producto, sin nombres ni teléfonos.

Después:
1. Agrupa las preguntas en patrones (por ejemplo talla, envío, cómo se usa, si sirve para algo puntual) y di cuántas hay de cada uno.
2. Reescribe la ficha para que responda esas dudas antes de que las pregunten: título, primer párrafo con el beneficio principal, viñetas con lo que más preguntan, preguntas frecuentes y una línea final que invite a comprar.
3. Usa el lenguaje de los clientes, no el de un catálogo. Frases cortas.
4. No inventes datos como medidas, materiales o tiempos. Si falta algo, márcalo como [COMPLETAR].

Entrega la ficha lista para pegar en Shopify.
