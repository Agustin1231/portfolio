---
name: carritos
description: Escribe la secuencia de 3 mensajes de WhatsApp para recuperar carritos abandonados de una tienda online, pensada en lo que frena a sus clientes. Úsala cuando pida /carritos, recuperar carritos abandonados o mensajes de recordatorio de compra.
---

# Tres mensajes para recuperar un carrito

Si no te los dio, pide primero:
- Qué vende y a quién.
- El valor promedio de un pedido.
- Lo que más frena a sus clientes antes de pagar (por ejemplo el envío, la talla, desconfianza o el precio).
- Lo que puede ofrecer sin perder plata (envío gratis desde cierto valor, un regalo o nada).

Reglas:
- Mensaje 1, a la hora: recordatorio amable con su nombre, el producto y el enlace del carrito. Sin descuento.
- Mensaje 2, al día siguiente: resuelve la duda que más frena la compra y ofrece ayuda directa.
- Mensaje 3, a los 3 días: una razón distinta para volver (lo que dicen otros clientes, pocas unidades o lo que puede ofrecer) y un cierre sin presión.
- Máximo 4 líneas por mensaje, tono cercano y como mucho un emoji.
- Usa variables entre llaves: {{nombre}}, {{producto}} y {{enlace}}.

Entrega además 2 versiones del mensaje 1 para probar cuál funciona mejor. Al final avisa que, si el cliente no ha escrito en 24 horas, en WhatsApp el mensaje tiene que salir como plantilla aprobada por Meta.
