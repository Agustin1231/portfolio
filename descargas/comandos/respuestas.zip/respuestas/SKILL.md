---
name: respuestas
description: Encuentra las 10 preguntas que más le repiten los clientes a una tienda por WhatsApp y escribe una respuesta corta para cada una, con un atajo para las respuestas rápidas de WhatsApp Business. Úsala cuando pida /respuestas, respuestas rápidas o preguntas frecuentes.
---

# Respuestas rápidas para WhatsApp Business

Si no te los dio, pide primero:
- Conversaciones de WhatsApp de la tienda, o la lista de preguntas que más le hacen (sin nombres ni teléfonos).
- Envíos: a dónde envía, con quién, cuánto tarda y cuánto cuesta.
- Formas de pago.
- Cambios y devoluciones.
- Horario de atención.

Después:
1. Encuentra las 10 preguntas que más se repiten.
2. Escribe una respuesta para cada una, de máximo 3 líneas, cálida y directa, como si la escribiera una persona del equipo. Que termine invitando al siguiente paso (ver el producto, pagar o pedir la guía).
3. Ponle a cada una un atajo corto de una palabra para las respuestas rápidas de WhatsApp Business, por ejemplo /envio o /pagos.
4. Si una respuesta necesita un dato que no tienes, déjalo como [COMPLETAR].

Entrégalo en una tabla con tres columnas: atajo, pregunta y respuesta. Al final recuerda dónde se guardan: WhatsApp Business > Herramientas para la empresa > Respuestas rápidas.
