---
name: combos
description: Lee el archivo de pedidos exportado de Shopify, encuentra qué productos se compran juntos y propone 3 combos con precio, textos para anunciarlos y un plan de prueba de 2 semanas. Úsala cuando pida /combos, armar combos u ofertas, o subir el valor promedio por pedido.
---

# Combos con lo que ya se compra junto

Si no te lo dio, pide el CSV de pedidos de los últimos 3 meses (Shopify > Pedidos > Exportar). Recuerda que antes de subirlo borre las columnas de nombre, correo, teléfono y dirección.

Con el archivo:
1. Encuentra los productos que más se compran juntos en el mismo pedido y da el top 5 de parejas o tríos, con cuántas veces pasó cada uno.
2. Calcula el valor promedio por pedido hoy.
3. Propón 3 combos para subirlo: qué productos lleva cada uno, precio sugerido, cuánto se ahorra el cliente frente a comprarlos por separado y a qué tipo de cliente va dirigido.
4. Para cada combo escribe un nombre, una descripción de 2 líneas y un mensaje corto para anunciarlo por WhatsApp e Instagram.
5. Da un plan para probarlos 2 semanas: qué medir y con qué número decidir si el combo sigue o se cambia.

No inventes productos que no estén en el archivo.
